// ─── VidGuard Background Service Worker ───────────────────────────────────────

const API_BASE    = "https://extensionbackend-435925497959.us-central1.run.app";
const FRAME_COUNT = 10;
const WEB_APP     = "https://vidguard-frontend-435925497959.us-central1.run.app";

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

  if (message.type === "ANALYZE_IMAGE") {
    analyzeImage(message.payload)
      .then((result) => sendResponse({ ok: true, result }))
      .catch((err)   => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.type === "GET_SETTINGS") {
    chrome.storage.sync.get(
      { showOnFake: false },
      (settings) => sendResponse({ ok: true, settings })
    );
    return true;
  }

  if (message.type === "SAVE_SETTINGS") {
    chrome.storage.sync.set(message.payload, () => sendResponse({ ok: true }));
    return true;
  }
});

async function analyzeImage({ dataUrl }) {
  const fetchRes = await fetch(dataUrl);
  const blob     = await fetchRes.blob();

  const form = new FormData();
  form.append("image", blob, "frame.jpg");
  form.append("end_frame", String(FRAME_COUNT));

  const res = await fetch(`${API_BASE}/api/predict-image`, {
    method: "POST",
    body: form,
  });

  return parseResponse(res);
}

async function parseResponse(res) {
  let data;
  try { data = await res.json(); }
  catch { throw new Error(`Invalid response (${res.status})`); }

  if (!res.ok) throw new Error(data.error ?? `API error (${res.status})`);
  if (data.label === "UNKNOWN") throw new Error(data.error ?? "No face detected");

  return {
    verdict   : data.label === "REAL" ? "authentic" : "deepfake",
    confidence: Math.round(data.confidence * 10) / 10,
    webAppUrl : data.web_app_url ?? WEB_APP,
  };
}
