# VidGuard Chrome Extension

Real-time deepfake detection for **TikTok**, **YouTube Shorts**, and **Instagram Reels** — powered by the VidGuard Xception AI backend.

---

## Installation (Developer Mode)

1. Open Chrome and navigate to `chrome://extensions`
2. Enable **Developer mode** (top-right toggle)
3. Click **Load unpacked**
4. Select the `vidguard-extension/` folder
5. The VidGuard shield icon will appear in your toolbar

---

## How it works

```
User watches a short video
        │
        ▼
content.js detects the <video> element
        │
        ├─ Tries to extract the video src URL
        │        │
        │        ▼
        │   background.js → POST /api/predict-url
        │
        └─ Falls back to canvas frame capture
                 │
                 ▼
            background.js → POST /api/predict (blob)
                 │
                 ▼
         VidGuard Xception model
                 │
                 ▼
        Result injected as overlay badge
```

### Overlay badge states

| State | Appearance |
|-------|-----------|
| Idle | Dark glass badge with "VidGuard" + "Scan" button |
| Scanning | Spinner + "Scanning…" |
| **DEEPFAKE** | Red badge with confidence % |
| **AUTHENTIC** | Green badge with confidence % |
| Error | Amber "No face detected" |

Click the **expand icon** on any result badge to open the detail panel showing fake ratio, avg confidence, and per-frame chart.

---

## File structure

```
vidguard-extension/
├── manifest.json        # Extension config (MV3)
├── background.js        # Service worker — API calls
├── content.js           # Injected into TikTok/YouTube/Instagram
├── overlay.css          # Overlay badge & panel styles
├── popup.html           # Toolbar popup UI
├── popup.js             # Popup logic & settings
└── icons/
    ├── icon16.png
    ├── icon48.png
    └── icon128.png
```

---

## Settings

| Setting | Default | Description |
|---------|---------|-------------|
| Auto-scan | ON | Scan automatically when a video plays |
| Alert on deepfakes only | OFF | Hide badge when video is authentic |
| Frames to analyse | 20 | Higher = more accurate but slower (max 60 for live use) |

---

## Platform support

| Platform | Detection method |
|----------|-----------------|
| TikTok | `.DivVideoContainer` / `.video-feed-item` selectors |
| YouTube Shorts | `/shorts/` URL + `ytd-reel-video-renderer` |
| Instagram Reels | `/reels/` URL + role=dialog containers |

---

## Backend API

The extension points to:
```
https://vidguard-435925497959.us-central1.run.app
```

- `POST /api/predict` — accepts `multipart/form-data` with `video` file + `end_frame`
- `POST /api/predict-url` — accepts `url` + `end_frame` (server-side proxy)

To point to a local backend, update `API_BASE` in `background.js`.

---

## Notes

- **Blob URLs** (used by TikTok/Instagram): the extension falls back to canvas frame capture and sends a JPEG to `/api/predict`
- **CORS**: Your backend must allow `chrome-extension://` origins, or use the background service worker as a proxy (already implemented)
- The extension uses `chrome.storage.sync` for settings and `chrome.storage.session` for per-session scan stats
